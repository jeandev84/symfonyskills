<?php include('includes/_header.php'); ?>
<?php include('includes/_menu.php'); ?>

<h1 class="text-info mb-5 mt-4">Where the best videos happens</h1>

<div class="embed-responsive embed-responsive-16by9">
    <iframe class="embed-responsive-item" src="https://player.vimeo.com/video/137857207" allowfullscreen></iframe>
</div>

<?php include('includes/_footer_links.php'); ?>
<?php include('includes/_footer.php'); ?>