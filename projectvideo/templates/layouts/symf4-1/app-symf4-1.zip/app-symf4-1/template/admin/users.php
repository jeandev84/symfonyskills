<?php include('includes/_header.php'); ?>
 <h2>Users</h2>

    <div class="table-responsive">
        <table class="table table-striped table-sm">
        <thead>
            <tr>
            <th>#</th>
            <th>Name</th>
            <th>Last name</th>
            <th>Email</th>
            <th>Delete</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach(range(1,10) as $v): ?>
            <tr>
            <td><?=$v?></td>
            <td>Adam</td>
            <td>Smith</td>
            <td>adam@smith.com</td>
            <td><a href="#" onclick="return confirm('Are you sure?');"><i class="fas fa-trash"></i></a></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
        </table>
    </div>

<?php include('includes/_footer.php'); ?>