<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
    <h5 class="my-0 mr-md-auto font-weight-normal"><a href="index.php">Awesome Videos</a></h5>

    <form method="POST" class="form-inline my-0 mr-md-auto" action="search_results.php">
        <input class="form-control mr-sm-2" type="search" placeholder="video title" aria-label="Search video">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search video</button>
    </form>

    <nav class="my-2 my-md-0 mr-md-3">
        <a class="p-2 text-dark" href="videolist.php">Funny</a>
        <a class="p-2 text-dark" href="videolist.php">Scary</a>
        <a class="p-2 text-dark" href="videolist.php">Unbelievable</a>
        <a class="p-2 text-dark" href="videolist.php">Inspirational</a>
        <a class="p-2 text-dark" href="videolist.php">Motivating</a>
        <a class="p-2 text-dark" href="admin/my_profile.php">My account</a>
    </nav>
    <a class="btn btn-outline-primary mr-2" href="pricing.php">Sign up</a>
    <a class="btn btn-outline-primary" href="login.php">Sign in</a>
</div>