<footer class="pt-4 my-md-5 pt-md-5 border-top">
    <div class="row">
        <div class="col-12 col-md">
            <small class="d-block mb-3 text-muted">&copy; 2017-2018</small>
        </div>
        <div class="col-6 col-md">
            <h5>Features</h5>
            <ul class="list-unstyled text-small">
                <li><a class="text-muted" href="#">Live streaming</a></li>
                <li><a class="text-muted" href="#">Video player</a></li>
                <li><a class="text-muted" href="#">Monetization</a></li>
                <li><a class="text-muted" href="#">Hosting</a></li>
                <li><a class="text-muted" href="#">Privacy</a></li>
                <li><a class="text-muted" href="#">Analytics</a></li>
                <li><a class="text-muted" href="#">Speed test</a></li>
            </ul>
        </div>
        <div class="col-6 col-md">
            <h5>Resources</h5>
            <ul class="list-unstyled text-small">
                <li><a class="text-muted" href="#">Help center</a></li>
                <li><a class="text-muted" href="#">Blog</a></li>
                <li><a class="text-muted" href="#">Guidelines</a></li>
                <li><a class="text-muted" href="#">Developers</a></li>
            </ul>
        </div>
        <div class="col-6 col-md">
            <h5>About</h5>
            <ul class="list-unstyled text-small">
                <li><a class="text-muted" href="#">Team</a></li>
                <li><a class="text-muted" href="#">Contact</a></li>
                <li><a class="text-muted" href="#">Jobs</a></li>
                <li><a class="text-muted" href="#">Partners</a></li>
                <li><a class="text-muted" href="#">Terms</a></li>
            </ul>
        </div>
    </div>
</footer>