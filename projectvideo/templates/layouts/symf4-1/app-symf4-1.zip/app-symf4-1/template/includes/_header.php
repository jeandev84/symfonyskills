<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/styles.css">

    <style>
        .form-control {
        background-color: #f8f5f5;
        }
    </style>

    <link rel="stylesheet" href="assets/css/fontawesome.min.css">

    <title>Symfony 4 course app - video sharing service</title>

</head>

<body class="text-center">
    <div class="container-fluid">