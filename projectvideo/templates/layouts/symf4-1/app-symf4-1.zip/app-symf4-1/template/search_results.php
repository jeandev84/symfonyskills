<?php include('includes/_header.php'); ?>
<?php include('includes/_menu.php'); ?>

<section class="jumbotron text-center">
    <div class="container">
        <h1 class="jumbotron-heading">No results were found</h1>
        <h1 class="jumbotron-heading">Search results</h1>
    </div>
</section>

<?php include('includes/_footer_links.php'); ?>
<?php include('includes/_footer.php'); ?>